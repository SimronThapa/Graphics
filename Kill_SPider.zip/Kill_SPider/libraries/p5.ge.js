
function setDeltaTime() {
	deltaTime = 0;
	prevTime = millis();	
}
function runDeltaTime(){
	deltaTime = (millis()-prevTime)/1000;
	prevTime = millis();
}

function GameObject(arg0,xPos,yPos) {
	this.name = arg0;
	this.variable = "hey";
	this.x = xPos;
	this.y = yPos;
	this.disX = 0;
	this.disY = 0;
	this.sprite = new Sprite(this.x,this.y);
	this.velocity = 0;
	this.direction = 0;
	this.fontColor = color(0);
	this.textField;
	this.textFont;
	this.fontSize = 16;
	this.alignment = LEFT;
	this.destroy = function() {
	}
	this.mouseClicked = function(xPos, yPos) {
		if(this.sprite.currentState != undefined && xPos >= this.x+this.sprite.currentState.left && xPos <= this.x+this.sprite.currentState.right &&
			yPos <= this.y+this.sprite.currentState.down && yPos >= this.y+this.sprite.currentState.up) {
				return true;
			}
			else return false;
	}
	this.mouseReleased = function(xPos, yPos) {
		//print(this.sprite.currentState);
		if(this.sprite.currentState != undefined && xPos >= this.x+this.sprite.currentState.left && xPos <= this.x+this.sprite.currentState.right &&
			yPos <= this.y+this.sprite.currentState.down && yPos >= this.y+this.sprite.currentState.up) {
				return true;
			}
			else return false;
	}
	this.translate = function(xPos,yPos) {
		this.x += xPos;
		this.y += yPos;
		push();
		translate(this.x,this.y);
		pop();
	}
	this.draw = function() {
		push();
		translate(this.x, this.y);
		this.x += Math.cos(radians(this.direction))*this.velocity*deltaTime;
		this.y += Math.sin(radians(-this.direction))*this.velocity*deltaTime;
		if(this.sprite.currentState != null) 
			this.sprite.draw();

		else if(this.textField != undefined) {
			textFont(this.textFont);
			textSize(this.fontSize);
			fill(this.fontColor);
			textAlign(this.alignment);
			text(this.textField,this.x-textWidth(this.textField)/2,this.y);
		}
		pop();
	}
}

//sprite and animation
function Sprite() {
	this.states =[];
	this.currentState;
	this.state = function(arg0) {
		if(this.states.length != 0){
			for(var i = 0; i < this.states.length; i++) {
				if(this.states[i].name == arg0) {
					this.currentState.stop();
					this.currentState = this.states[i];
					return this.states[i];
				}
			}
		}
		this.newState = new this.State(arg0,this.x,this.y);
		this.states.push(this.newState);
		if(this.states.length == 1)
			this.currentState = this.newState;
		return this.newState;
	}
	this.State = function(arg0) {
		this.left, this.right, this.up, this.down;
		this.name = arg0;
		this.image;
		this.frames = 1;
		this.index = 0;
		this.frameWidth, this.frameHeight;
		this.isSpriteSheet = false;
		this.animationSpeed = 1;
		this.frameTime = 1/frameRate()/this.animationSpeed;
		this.startFrame, this.endFrame;
		this.timeCounter = 0;
		this.xScale = 1;
		this.yScale = 1;
		this.isPlaying = false;
		this.rotation = 0;
		
		this.play = function() {
			this.isPlaying = true;
		}
		this.pause = function() {
			this.isPlaying = true;
		}
		this.stop = function() {
			this.frame = 0;
			this.isPlaying = false;
		}
		this.draw = function (){ 
			push();
			//scale(this.xScale,this.yScale);
			if(this.image !== undefined) {
				this.frameRows = Math.ceil(this.frames*this.frameWidth/this.image.width);
				if(this.width == undefined)
					this.width = this.image.width;
				if(this.height == undefined)
					this.height = this.image.height;
				this.left = -this.width/2*this.xScale;
				this.right = this.width/2*this.xScale;
				this.up = -this.height/2*this.yScale;
				this.down = +this.height/2*this.yScale;
				if(!this.isSpriteSheet)
					image(this.image,this.left,this.up,this.width,this.height);
				else {
					if(this.isPlaying){
						this.frameTime = 1/frameRate()/this.animationSpeed;
						this.timeCounter += deltaTime;
						if(this.timeCounter > this.frameTime){
							this.timeCounter -= this.frameTime;
							this.index +=1
							if(this.index > (this.endFrame-this.startFrame))
								this.index = 0;
						}
					} 

					//imageMode(CENTER);
					image(this.image,this.left,this.up,this.frameWidth,this.frameHeight,(((this.startFrame+this.index)*this.frameWidth)%this.width),Math.floor((this.startFrame+this.index)*this.frameWidth/this.image.width)*this.frameHeight,this.frameWidth,this.frameHeight);
				//	imageMode(CORNER);
				//	print("image(" + this.left + "," + this.up + ",256,256,256,0,256,256);\nvs");
				    //print(this.name + ": " + (((this.startFrame+this.index)*this.frameWidth)%this.width) + ", " + (Math.floor((this.startFrame+this.index)*this.frameWidth/this.image.width)*this.frameHeight));
				//print(this.name + ":(Math.floor((" + this.startFrame+ "+"+this.index+")*"+this.frameWidth+"/"+this.image.width+")*"+this.frameHeight+")) = " + (Math.floor((this.startFrame+this.index)*this.frameWidth/this.image.width)*this.frameHeight));
					//print("image(" + this.left + "," + this.up + ","+this.frameWidth+","+this.frameHeight+","+(this.startFrame*this.frameWidth+this.index*this.width)+","+Math.floor(this.index*this.frameWidth/this.image.width)*this.frameHeight+","+this.frameWidth+","+this.frameHeight+");");
				}
				
			}
			pop();
		}
	}	

	this.draw = function() {
		if(this.currentState != undefined) {
			this.currentState.draw();	
		}
	}
}
//math functions
function radians(degrees) {
	return degrees * Math.pi / 180;
}