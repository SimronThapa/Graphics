var room;
/*	0 = Menu
 *  1 = Game
 *	2 = Scoreboard 
 * */
 var screenWidth, screenHeight;
 var rooms = [];
 var gameObjects = [];
 var score = 0;
function preload() {
	imgTitle = loadImage("images/title.png");
	imgMenuBG = loadImage("images/infested_floor.png");
	imgPlayButton = [loadImage("images/button_play.png"),loadImage("images/button_play_selected.png"),loadImage("images/button_play_clicked.png")];
	imgOptionsButton = [loadImage("images/button_options.png"),loadImage("images/button_options_selected.png"),loadImage("images/button_options_clicked.png")];
	gameFont = loadFont("fofbb_reg.ttf");
	imgSpider = loadImage("images/spider.png");
}
function setup() {
	setDeltaTime();
	screenWidth = windowHeight*1920/1080;
	screenHeight = windowHeight;
	createCanvas(screenWidth,screenHeight);
	room = new Menu();
	room.keyReleased();
	angleMode(DEGREES);
}

function draw() {
	runDeltaTime();
	clear();
	room.draw();


}
function keyReleased() {
	room.keyReleased();
}

function mousePressed() {
	room.mousePressed();
}
function mouseReleased() {
	room.mouseReleased();
}


function Menu() {
	var selectIndex = 0; //0 = Play, 1 = Options
	var title = new GameObject("title",screenWidth/2,-100);
	this.gameObject = [title];
	title.sprite.state("title").image = imgTitle;
	title.sprite.state("title").width = imgTitle.width*0.75;
	title.sprite.state("title").height = imgTitle.height*0.75;
	title.direction = 270;
	title.velocity = 10;
	
	var menuPlay = new GameObject("menuPlay",screenWidth/2,screenHeight+100);
	var menuOptions = new GameObject("menuOptions",screenWidth/2,screenHeight+200);
	this.gameObject.push(menuPlay);
	//this.gameObject.push(menuOptions);
	menuPlay.sprite.state("normal").image = imgPlayButton[0];
	menuPlay.sprite.state("normal").width = imgPlayButton[0].width*0.5;
	menuPlay.sprite.state("normal").height = imgPlayButton[0].height*0.5;
	menuPlay.sprite.state("selected").image = imgPlayButton[1];
	menuPlay.sprite.state("selected").width = imgPlayButton[1].width*0.5;
	menuPlay.sprite.state("selected").height = imgPlayButton[1].height*0.5;
	menuPlay.sprite.state("clicked").image = imgPlayButton[2];
	menuPlay.sprite.state("clicked").width = imgPlayButton[2].width*0.5;
	menuPlay.sprite.state("clicked").height = imgPlayButton[2].height*0.5;
	menuOptions.sprite.state("normal").image = imgOptionsButton[0];
	menuOptions.sprite.state("normal").width = imgOptionsButton[0].width*0.5;
	menuOptions.sprite.state("normal").height = imgOptionsButton[0].height*0.5;
	menuOptions.sprite.state("selected").image = imgOptionsButton[1];
	menuOptions.sprite.state("selected").width = imgOptionsButton[1].width*0.5;
	menuOptions.sprite.state("selected").height = imgOptionsButton[1].height*0.5;
	menuOptions.sprite.state("clicked").image = imgOptionsButton[2];
	menuOptions.sprite.state("clicked").width = imgOptionsButton[2].width*0.5;
	menuOptions.sprite.state("clicked").height = imgOptionsButton[2].height*0.5;
	menuPlay.direction = 90;
	menuOptions.direction = 90;
	menuPlay.velocity = 10;
	menuOptions.velocity = 10;

	this.keyReleased = function(){
		if(keyCode === 38 || keyCode === 87) {
			//selectIndex = (selectIndex == 0) ? 1 : 0; 
		}
		if(keyCode === 40 || keyCode === 83) {
			//selectIndex = (selectIndex == 1) ? 0 : 1; 
		}
		if(keyCode === 32 || keyCode === 13) {
			switch(selectIndex) {
				case 0: 
					room = new Game();
					break;
				case 1:
					room = new Options();
			}
		}
	}
	this.mousePressed = function() {
	
	}
	this.mouseReleased = function() {
		for(var i = 0; i < this.gameObject.length; i++) {
			if(this.gameObject[i].mouseReleased(mouseX,mouseY)){
				if(this.gameObject[i].name = "menuPlay"){
					room = new Game();
					return;
				}
			}
		}		
	}
	this.draw = function() {
		if(title.y >  screenHeight/4 && title.velocity !== 0) {
			title.y = screenHeight/4;
			title.velocity = 0;
		}
		if(title.y <= screenHeight/4){
			title.velocity = 400*(1-(title.y/(screenHeight/4+10)));
		}
		if(menuPlay.y < screenHeight/2 && menuPlay.velocity !== 0) {
			menuPlay.velocity = 0;
			menuOptions.velocity = 0;
		}
		if(menuPlay.y >= screenHeight/2){
			menuPlay.velocity = 750*(1-((screenHeight/2-10)/menuPlay.y));
			menuOptions.velocity = menuPlay.velocity;
		}
		switch(selectIndex){
			case 0:
				menuPlay.sprite.state("selected");
				menuOptions.sprite.state("normal");
				break;
			case 1:
				menuPlay.sprite.state("normal");
				menuOptions.sprite.state("selected");
				break;
		}
		image(imgMenuBG,0,0,screenWidth,screenHeight);
		for(var i = 0; i < this.gameObject.length; i++) {
			this.gameObject[i].draw();
		}

	}
}

function Game() {
	score = 0;
	this.gameObject = [];
	scoreUI = new GameObject("scoreUI",screenWidth/8,-100);
	timeUI = new GameObject("timeUI",screenWidth/8*3,-100);
	this.gameObject.push(scoreUI);
	this.gameObject.push(timeUI);
	scoreUI.textFont = gameFont;
	scoreUI.fontSize = 64;
	scoreUI.fontColor = color(255,0,0);
	scoreUI.textField = "0";

	scoreUI.textAlign = CENTER;
	scoreUI.direction = 270;
	timeUI.textFont = gameFont;
	timeUI.fontSize = 64;
	timeUI.fontColor = color(255,0,0);
	timeUI.textField = "60";
	var endTime = (millis()/1000) + 31;
	spider = [];
	spiderState = []; //0 stopped, 1 move, 2 dead
	spiderStateTimer = [];
	spiderSpawn = false;
	spiderTimer = 0;
	
	for(var i = 0; i < 25; i++) {
		spawnSpider(this.gameObject,i);
	}
	this.keyReleased = function(){
		if(keyCode === 32) {
			room = new Game();
		}
		if(keyCode === 27) {
			room = new Menu();
		}
	}
	this.mouseIsPressed = function(){
	}
	this.draw = function(){
		if(spiderSpawn){
			spiderTimer -= deltaTime;
		}
		if(spiderSpawn && spiderTimer < 0) {
			spiderTimer = 0;
			spiderSpawn = false;
			spawnSpider(this.gameObject,spider.length);
		}
		image(imgMenuBG,0,0,screenWidth,screenHeight);
		timeUI.textField = Math.floor(endTime - millis()/1000).toString();
		if(timeUI.textField == "-1"){
			room = new Scoreboard();
		}
		scoreUI.textField = score.toString();
		if(scoreUI.y > screenHeight/16 && scoreUI.velocity !== 0) {
			scoreUI.y = screenHeight/16;
			scoreUI.velocity = 0;
		}
	if(scoreUI.y <= screenHeight/16) {
		scoreUI.velocity = 200*(1-(scoreUI.y/(screenHeight/16+1)));
	}
	timeUI.y = scoreUI.y;
	push();
	if(spider != undefined){
		for(var i = 0; i < spider.length; i++) {
			spiderStateTimer[i] -= deltaTime;
			//print(spider[i].direction);
			//print(spiderStateTimer[i]);
			if(spiderStateTimer[i] < 0) {
				//print("state: " + spiderState[i]);

				if(spiderState[i] === 0) {
				spiderStateTimer[i] = random(-spiderStateTimer[i],(2-spiderStateTimer[i])*((1000+score)/1000));
					spiderState[i] = 1;			
					spider[i].direction = Math.round(random(0,3))*90;
					switch(spider[i].direction) {
						case 0: 
							spider[i].sprite.state("move right");
							break;
						case 90: 
							spider[i].sprite.state("move up");
							break;
						case 180: 
							spider[i].sprite.state("move left");
							break;				
						case 270: 
							spider[i].sprite.state("move down");
							break;					
					}
					spider[i].velocity = 100*((1000+score)/1000);
					spider[i].sprite.currentState.play();
				}
				else if(spiderState[i] === 1) {
					print((2-spiderStateTimer[i])*((1000/(1000+score))));
				spiderStateTimer[i] = random(-spiderStateTimer[i],(2-spiderStateTimer[i])*((1000/(1000+score))));
					spiderState[i] = 0;
					switch(spider[i].direction) {
						case 0: 
							spider[i].sprite.state("idle right");
							break;
						case 90: 
							spider[i].sprite.state("idle up");
							break;
						case 180: 
							spider[i].sprite.state("idle left");
							break;				
						case 270: 
							spider[i].sprite.state("idle down");
							break;					
					}
					spider[i].velocity = 0;
				}
			}
			if(spider[i].y < 256  && spider[i].direction == 90|| spider[i].y > windowHeight && spider[i].direction == 270|| spider[i].x < 256 && spider[i].direction == 180|| spider[i].x > screenWidth && spider[i].direction == 0) {
				spider[i].direction += 180;
				if(spider[i].direction >= 360)
					spider[i].direction -= 360;
				if(spider[i].direction < 0)
					spider[i].direction += 360;
					switch(spider[i].direction) {
						case 0: 
							spider[i].sprite.state("move right");
							break;
						case 90: 
							spider[i].sprite.state("move up");
							break;
						case 180: 
							spider[i].sprite.state("move left");
							break;				
						case 270: 
							spider[i].sprite.state("move down");
							break;					
					}
					spider[i].sprite.currentState.play();
			}
		}
	}
	pop();
		for(var i = 0; i < this.gameObject.length; i++) {
			
			this.gameObject[i].draw();
		}
	}
	this.mouseReleased = function() {
		for(var i = 0; i < this.gameObject.length; i++) {
			this.gameObject[i].mouseClicked(mouseX,mouseY);
		}		
	}
	this.mousePressed= function() {
		for(var i = 0; i < this.gameObject.length; i++) {

			if(this.gameObject[i].mouseReleased(mouseX,mouseY)){
				if(this.gameObject[i].name == "spider");
					if(this.gameObject[i].sprite.currentState != this.gameObject[i].sprite.state("dead")) {
						score += 100;
						for(var j = 0; j < spider.length; j++) {
							if(spider[j] == this.gameObject[i])
								spiderState[j] = 2
								spiderTimer = random(0,4)*(300/(300+score));;
								spiderSpawn = true;
						}
						this.gameObject[i].velocity = 0;
						this.gameObject[i].sprite.state("dead");
						return;
						//print(score.toString());
					}
			}
		}		
	}
}

function Options() {
	
}

function Scoreboard() {
	this.gameObject = [];
	scoreUI = new GameObject("scoreUI",screenWidth/4,screenHeight/4);
	this.gameObject.push(scoreUI);
	scoreUI.textFont = gameFont;
	scoreUI.fontSize = 64;
	scoreUI.fontColor = color(255,0,0);
	scoreUI.textField = "0";
	scoreUI.textAlign = CENTER;
	scoreUI.direction = 270;
	
var menuPlay = new GameObject("menuPlay",screenWidth/2,screenHeight-100);
	this.gameObject.push(menuPlay);
	//this.gameObject.push(menuOptions);
	menuPlay.sprite.state("normal").image = imgPlayButton[0];
	menuPlay.sprite.state("normal").width = imgPlayButton[0].width*0.5;
	menuPlay.sprite.state("normal").height = imgPlayButton[0].height*0.5;
	menuPlay.sprite.state("selected").image = imgPlayButton[1];
	menuPlay.sprite.state("selected").width = imgPlayButton[1].width*0.5;
	menuPlay.sprite.state("selected").height = imgPlayButton[1].height*0.5;
	menuPlay.sprite.state("clicked").image = imgPlayButton[2];
	menuPlay.sprite.state("clicked").width = imgPlayButton[2].width*0.5;
	menuPlay.sprite.state("clicked").height = imgPlayButton[2].height*0.5;
	menuPlay.sprite.state("selected")
	this.draw = function(){
		image(imgMenuBG,0,0,screenWidth,screenHeight);

		for(var i = 0; i < this.gameObject.length; i++) {
			
			this.gameObject[i].draw();
		}
	}
	this.keyReleased = function(){
		if(keyCode === 27) {
			room = new Menu();
		}
		if(keyCode === 32 || keyCode === 13) {
				room = new Game();
			}
		}
	this.mousePressed = function() {
	
	}
	this.mouseReleased = function() {
		for(var i = 0; i < this.gameObject.length; i++) {
			if(this.gameObject[i].mouseReleased(mouseX,mouseY)){
				if(this.gameObject[i].name = "menuPlay"){
					room = new Game();
					return;
				}
			}
		}		
	}
}

function spawnSpider(go,i){
			spider[i] = new GameObject("spider",random(0,screenWidth),random(0,screenHeight));
		//spider[i] = new GameObject(screenWidth/2,screenHeight/2);
		spider[i].sprite.state("idle left").image = imgSpider;
		spider[i].sprite.state("idle left").frames = 1;
		spider[i].sprite.state("idle left").isSpriteSheet = true;
		spider[i].sprite.state("idle left").xScale = 0.25;
		spider[i].sprite.state("idle left").yScale = 0.25;
		spider[i].sprite.state("idle left").frameWidth = 64;
		spider[i].sprite.state("idle left").frameHeight = 64;
		spider[i].sprite.state("idle left").startFrame = 13;
		spider[i].sprite.state("idle left").endFrame = 13;
		
		spider[i].sprite.state("idle right").image = imgSpider;
		spider[i].sprite.state("idle right").frames = 1;
		spider[i].sprite.state("idle right").isSpriteSheet = true;
		spider[i].sprite.state("idle right").xScale = 0.25;
		spider[i].sprite.state("idle right").yScale = 0.25;
		spider[i].sprite.state("idle right").frameWidth = 64;
		spider[i].sprite.state("idle right").frameHeight = 64;
		spider[i].sprite.state("idle right").startFrame = 5;
		spider[i].sprite.state("idle right").endFrame = 5;
		
		spider[i].sprite.state("idle up").image = imgSpider;
		spider[i].sprite.state("idle up").frames = 1;
		spider[i].sprite.state("idle up").isSpriteSheet = true;
		spider[i].sprite.state("idle up").xScale = 0.25;
		spider[i].sprite.state("idle up").yScale = 0.25;
		spider[i].sprite.state("idle up").frameWidth = 64;
		spider[i].sprite.state("idle up").frameHeight = 64;
		spider[i].sprite.state("idle up").startFrame = 1;
		spider[i].sprite.state("idle up").endFrame = 1;
	
		spider[i].sprite.state("idle down").image = imgSpider;
		spider[i].sprite.state("idle down").frames = 1;
		spider[i].sprite.state("idle down").isSpriteSheet = true;
		spider[i].sprite.state("idle down").xScale = 0.25;
		spider[i].sprite.state("idle down").yScale = 0.25;
		spider[i].sprite.state("idle down").frameWidth = 64;
		spider[i].sprite.state("idle down").frameHeight = 64;
		spider[i].sprite.state("idle down").startFrame = 9;
		spider[i].sprite.state("idle down").endFrame = 9;

		spider[i].sprite.state("move left").image = imgSpider;
		spider[i].sprite.state("move left").frames = 3;
		spider[i].sprite.state("move left").isSpriteSheet = true;
		spider[i].sprite.state("move left").xScale = 0.25;
		spider[i].sprite.state("move left").yScale = 0.25;
		spider[i].sprite.state("move left").frameWidth = 64;
		spider[i].sprite.state("move left").frameHeight = 64;
		spider[i].sprite.state("move left").startFrame = 12;
		spider[i].sprite.state("move left").endFrame = 14;
		spider[i].sprite.state("move left").animationSpeed = 0.25;
		
		spider[i].sprite.state("move right").image = imgSpider;
		spider[i].sprite.state("move right").frames = 3;
		spider[i].sprite.state("move right").isSpriteSheet = true;
		spider[i].sprite.state("move right").xScale = 0.25;
		spider[i].sprite.state("move right").yScale = 0.25;
		spider[i].sprite.state("move right").frameWidth = 64;
		spider[i].sprite.state("move right").frameHeight = 64;
		spider[i].sprite.state("move right").startFrame = 4;
		spider[i].sprite.state("move right").endFrame = 6;
		spider[i].sprite.state("move right").animationSpeed = 0.25;
	
		spider[i].sprite.state("move up").image = imgSpider;
		spider[i].sprite.state("move up").frames = 1;
		spider[i].sprite.state("move up").isSpriteSheet = true;
		spider[i].sprite.state("move up").xScale = 0.25;
		spider[i].sprite.state("move up").yScale = 0.25;
		spider[i].sprite.state("move up").frameWidth = 64;
		spider[i].sprite.state("move up").frameHeight = 64;
		spider[i].sprite.state("move up").startFrame = 0;
		spider[i].sprite.state("move up").endFrame = 2;
		spider[i].sprite.state("move up").animationSpeed = 0.25;
		
		spider[i].sprite.state("move down").image = imgSpider;
		spider[i].sprite.state("move down").frames = 3;
		spider[i].sprite.state("move down").isSpriteSheet = true;
		spider[i].sprite.state("move down").xScale = 0.25;
		spider[i].sprite.state("move down").yScale = 0.25;
		spider[i].sprite.state("move down").frameWidth = 64;
		spider[i].sprite.state("move down").frameHeight = 64;
		spider[i].sprite.state("move down").startFrame = 8;
		spider[i].sprite.state("move down").endFrame = 10;
		spider[i].sprite.state("move down").animationSpeed = 0.25;

		spider[i].sprite.state("dead").image = imgSpider;
		spider[i].sprite.state("dead").frames = 1;
		spider[i].sprite.state("dead").isSpriteSheet = true;
		spider[i].sprite.state("dead").xScale = 0.25;
		spider[i].sprite.state("dead").yScale = 0.25;
		spider[i].sprite.state("dead").frameWidth = 64;
		spider[i].sprite.state("dead").frameHeight = 64;
		spider[i].sprite.state("dead").startFrame = 3;
		spider[i].sprite.state("dead").endFrame = 3;
		
		spider[i].direction = Math.round(random(0,3))*90;
		
		switch(spider[i].direction) {
			case 0: 
				spider[i].sprite.state("idle right");
				break;
			case 90: 
				spider[i].sprite.state("idle up");
				break;
			case 180: 
				spider[i].sprite.state("idle left");
				break;				
			case 270: 
				spider[i].sprite.state("idle down");
				break;					
			}
		spiderState[i] = 0;
		spiderStateTimer[i] = random(0,2);
		go.push(spider[i]);
}